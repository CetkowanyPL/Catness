const sagamWindow = document.getElementById("sagamWindow");
const titleBar = sagamWindow.querySelector(".title-bar");

let isDragging = false;
let offsetX, offsetY;

titleBar.addEventListener("mousedown", (e) => {
  isDragging = true;
  offsetX = e.clientX - sagamWindow.offsetLeft;
  offsetY = e.clientY - sagamWindow.offsetTop;
});

document.addEventListener("mousemove", (e) => {
  if (isDragging) {
    sagamWindow.style.left = `${e.clientX - offsetX}px`;
    sagamWindow.style.top = `${e.clientY - offsetY}px`;
  }
});

document.addEventListener("mouseup", () => {
  isDragging = false;
});