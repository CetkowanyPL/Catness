// mrauo.js – Styl systemowy Mrauo dla Catnessa

// Styl Mrauo jako obiekt
const mrauoStyle = {
  blur: true,
  glass: true,
  color: "aurora",
  dockAnimation: "mrugnięcie",
  borderRadius: "12px",
  shadow: "soft",
  theme: "dark"
};

// Funkcja aktywująca styl Mrauo
function activateMrauo() {
  const root = document.documentElement;

  // Przykładowe style CSS przez JS
  root.style.setProperty('--mrauo-blur', mrauoStyle.blur ? '8px' : '0');
  root.style.setProperty('--mrauo-color', mrauoStyle.color);
  root.style.setProperty('--mrauo-radius', mrauoStyle.borderRadius);
  root.style.setProperty('--mrauo-shadow', mrauoStyle.shadow === 'soft' ? '0 0 10px rgba(0,0,0,0.3)' : 'none');
  root.classList.add('theme-mrauo');

  console.log("Mrauo styl aktywowany.");
}

// Eksport funkcji (jeśli używasz modułów)
export { activateMrauo };