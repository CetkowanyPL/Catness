const canvas = document.getElementById("paintCanvas");
const ctx = canvas.getContext("2d");

let painting = false;
let lastX = 0;
let lastY = 0;

function getPos(e) {
    const rect = canvas.getBoundingClientRect();
    return {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
    };
}

canvas.addEventListener("mousedown", (e) => {
    painting = true;
    const pos = getPos(e);
    lastX = pos.x;
    lastY = pos.y;
});

canvas.addEventListener("mousemove", (e) => {
    if (!painting) return;
    const pos = getPos(e);

    ctx.strokeStyle = document.getElementById("paintColor").value;
    ctx.lineWidth = document.getElementById("paintSize").value;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";

    ctx.beginPath();
    ctx.moveTo(lastX, lastY);
    ctx.lineTo(pos.x, pos.y);
    ctx.stroke();

    lastX = pos.x;
    lastY = pos.y;
});

window.addEventListener("mouseup", () => {
    painting = false;
});

// Wyczyść
document.getElementById("paintClear").addEventListener("click", () => {
    ctx.fillStyle = "white";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
});

// Zapis PNG
document.getElementById("paintSavePng").addEventListener("click", () => {
    let name = document.getElementById("paintFilename").value.trim();
    if (!name) name = "rysunek";
    if (!name.endsWith(".png")) name += ".png";

    const link = document.createElement("a");
    link.href = canvas.toDataURL("image/png");
    link.download = name;
    link.click();
});

// Zapis .cp (JSON z PNG w base64)
document.getElementById("paintSaveCp").addEventListener("click", () => {
    const data = {
        type: "catness_paint",
        width: canvas.width,
        height: canvas.height,
        background: "white",
        imagePngBase64: canvas.toDataURL("image/png")
    };

    let name = document.getElementById("paintFilename").value.trim();
    if (!name) name = "rysunek";
    if (!name.endsWith(".cp")) name += ".cp";

    const blob = new Blob([JSON.stringify(data)], { type: "application/json" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = name;
    link.click();
});

// Wczytaj .cp
document.getElementById("paintLoadCp").addEventListener("change", function() {
    const file = this.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function(e) {
        const data = JSON.parse(e.target.result);

        const img = new Image();
        img.onload = function() {
            ctx.fillStyle = "white";
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(img, 0, 0);
        };
        img.src = data.imagePngBase64;
    };

    reader.readAsText(file);
});

// Wyjdź
document.getElementById("paintExit").addEventListener("click", () => {
    // dostosuj ścieżkę do swojego Catness OS
    window.location.href = "../index.html";
});
