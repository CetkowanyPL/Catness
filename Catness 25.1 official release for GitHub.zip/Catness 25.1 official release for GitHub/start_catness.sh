#!/bin/bash
xdg-open /home/mandziki/Catness/index.html

